import WeatherApp from './WeatherApp'

function App() {

  return (
    <>
      <WeatherApp/>
    </>
  )
}

export default App
